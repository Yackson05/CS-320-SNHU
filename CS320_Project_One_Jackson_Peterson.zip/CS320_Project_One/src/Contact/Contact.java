package Contact;

import java.util.UUID;

public class Contact {
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	private String id;
	
	private static final int GENERAL_LENGTH = 10;
	private static final byte CONTACT_ADDRESS_LENGTH = 30;
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	public String getID() {
		return id;
	}
	
	protected void setFirstName(String firstName) {
		if (firstName == null) {
			throw new IllegalArgumentException("First name must not be empty");
		} else if (firstName.length() > GENERAL_LENGTH) {
			throw new IllegalArgumentException("First name must not exceed " + 
					GENERAL_LENGTH + " characters");
		}
		this.firstName = firstName;
	}
	
	protected void setLastName(String lastName) {
		if (lastName == null) {
			throw new IllegalArgumentException("Last Name must not be empty");
		} else if (lastName.length() > GENERAL_LENGTH) {
			throw new IllegalArgumentException("Last Name must not exceed" + 
					GENERAL_LENGTH + " characters");
		}
		this.lastName = lastName;
	}
	
	protected void setPhone(String phone) {
		String regex = "[\\d]+";
		if (!phone.matches(regex)) {
			throw new IllegalArgumentException("Please enter a valid phone number. Only digits are allowed");
		}
		this.phone = phone;
	}
	
	protected void setAddress(String address) {
		if (address == null) {
			throw new IllegalArgumentException("Address must not be empty");
		} else if (address.length() > CONTACT_ADDRESS_LENGTH) {
			throw new IllegalArgumentException("Address must not be longer than" + 
					CONTACT_ADDRESS_LENGTH + "characters");
		}
		this.address = address;
	}
	
	protected void setUniqueId() {
		String uuid = UUID.randomUUID().toString();
		this.id = uuid.substring(uuid.length() - 16);
	}
	
	public Contact(String firstName, String lastName, String phone, String address) {
		setUniqueId();
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
		
		System.out.printf("%s",this.toString());
	}
	
	@Override
	public String toString() {
		return "Contact: ID=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", phone=" + phone + ", address=" + address;
	}
}
