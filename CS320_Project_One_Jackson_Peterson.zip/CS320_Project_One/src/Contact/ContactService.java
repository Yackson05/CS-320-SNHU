package Contact;

import java.util.ArrayList;

public class ContactService {
	private final ArrayList<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	public boolean addContact(Contact contact) {
		boolean isInArray = false;
		for (Contact contactObject : contacts) {
			if (contactObject.equals(contact)) {
				isInArray = true;
				break;
			}
			
		}
		if (!isInArray) {
			contacts.add(contact);
			return true;
		}
		return false;
	}
	
	public Contact getContact(String id) {
		for (Contact contactObject : contacts) {
			if (contactObject.getID().equals(id)) {
				return contactObject;
			}
		}
		return null;
	}
	
	public boolean deleteContact(String id) {
		Contact contact = getContact(id);
		if (contact != null) {
			contacts.remove(contact);
			return true;
		}
		return false;
	}
	
	public boolean isValid(String field, int maxLength) {
		return !(field.equals("") || field.length() > maxLength);
	}
	
	public boolean updateContact(String id, String firstName, String lastName, String phone, String address) {
		
		Contact contact = getContact(id);
		
		if (
			isValid(lastName, 10) &&
			isValid(firstName, 10) &&
			phone.length() == 10 &&
			isValid(address, 30)) {
			contact.setFirstName(firstName);
			contact.setLastName(lastName);
			contact.setPhone(phone);
			contact.setAddress(address);
			return true;
		}
		
		return false;
		
	}
}

