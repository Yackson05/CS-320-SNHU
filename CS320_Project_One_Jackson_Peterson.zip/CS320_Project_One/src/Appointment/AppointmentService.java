package Appointment;

import java.util.ArrayList;

public class AppointmentService {
	// Holds the list of appointment
	private final ArrayList<Appointment> appointments;
	
	public AppointmentService() {
		// Initialize the array list
		appointments = new ArrayList<>();
	}
	
	// Method to add a appointment
	public void addAppointment(Appointment appointment) {
		boolean isInArray = false;
		// Loops through all the appointment
		for (Appointment appointmentObject : appointments) {
			if (appointmentObject.equals(appointments)) {
				isInArray = true;
				break;
			}
		}
		if (!isInArray) {
			appointments.add(appointment);
			}
		}
	public Appointment getAppointment(String id) {
		for (Appointment appointmentObject : appointments) {
			// Checks if there is an appointment with that id
			if (appointmentObject.getID().equals(id)) {
				return appointmentObject;
			}
		}
		return null;
	}
	public boolean deleteAppointment(String id) {
		for (Appointment appointmentObject : appointments) {
			// Checks if there is an appointment with that id
			if (appointmentObject.getID().equals(id)) {
				appointments.remove(appointmentObject);
				return true;
			}
		}
		return false;
	}
}