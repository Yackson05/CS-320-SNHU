package Test;

import org.junit.Test;

public class TaskServiceTest {
	
	// Write tests to ensure TaskService class meets its requirements 
	@Test
	public void testAddTask() {
		// Implement test for adding a task
	}
	@Test
	public void testDeleteTask() {
		// Implement test for deleting a task
	}
	@Test
	public void testUpdateTask() {
		// Implement test for updating a task
		
	}
	// Add more tests as needed

}
