package Test;

import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

	// Write tests to ensure Task class meets its requirements
	@Test
	public void testTaskCreatoin() {
		//Implement test for task creation
	
	}
	
	// Add more tests as needed
}
