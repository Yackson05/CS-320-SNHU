package Task;

public class Task {
	private String taskId;
	private String name;
	private String description;
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	// Constructors, getters, setters, and any other necessary methods
	
	// ensure that equals and hashCode methods are overridden for proper comparison
}