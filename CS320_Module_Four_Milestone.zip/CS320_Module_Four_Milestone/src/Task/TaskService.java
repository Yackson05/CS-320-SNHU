package Task;

import java.util.List;

public class TaskService {
	private List<Task> tasks;
	
	public TaskService(List<Task> tasks) {
		this.tasks = tasks;
	}
	
	public void addTask(Task task) {
		//Implement logic to add a task
	}
	public void deleteTask(String taskId) {
		// Implement logic to delete a task based on task ID
	}
	public void updateTask(String taskId, String name, String description) {
		//Implement logic to update task fields based on task ID
	}
	
	//Additional methods if needed
	public List<Task> getTasks() {
		return tasks;
	}

}
