package Contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    // Constructor
    public ContactService() {
        this.contacts = new HashMap<>();
    }

    // Add a contact
    public void addContact(Contact contact) {
        contacts.put(contact.getContactID(), contact);
    }

    // Delete a contact
    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    // Update contact fields
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        Contact existingContact = contacts.get(contactID);
        if (existingContact != null) {
            // Update fields
            existingContact.firstName = firstName;
            existingContact.lastName = lastName;
            existingContact.phone = phone;
            existingContact.address = address;
        }
    }
}
