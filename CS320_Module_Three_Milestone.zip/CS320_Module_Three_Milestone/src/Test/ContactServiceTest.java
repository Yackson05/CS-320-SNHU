package Contact;
import org.junit.Test;
import static org.junit.Assert.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);

        assertTrue(contactService.getContacts().containsKey("12345"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.deleteContact("12345");

        assertFalse(contactService.getContacts().containsKey("12345"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.updateContact("12345", "Jane", "Smith", "0987654321", "456 Oak St");

        assertEquals("Jane", contactService.getContacts().get("12345").getFirstName());
        assertEquals("Smith", contactService.getContacts().get("12345").getLastName());
        assertEquals("0987654321", contactService.getContacts().get("12345").getPhone());
        assertEquals("456 Oak St", contactService.getContacts().get("12345").getAddress());
    }
}
